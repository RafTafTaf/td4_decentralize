export const REGISTRY_PORT = 8080;
export const BASE_ONION_ROUTER_PORT = 4000;
export const BASE_USER_PORT = 3000;
