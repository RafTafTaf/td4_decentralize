import { launchNetwork } from ".";

function main() {
  launchNetwork(10, 2);
}

main();
